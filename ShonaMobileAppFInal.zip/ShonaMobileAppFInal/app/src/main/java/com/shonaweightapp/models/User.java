package com.shonaweightapp.models;

import android.content.ContentValues;

public class User {
    String username,password;

    public User(){

    }
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public User(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public ContentValues getContentValuesToAdd(){
        ContentValues values = new ContentValues();
        values.put("username", getUsername());
        values.put("password",getPassword());
        return values;
    }

}
