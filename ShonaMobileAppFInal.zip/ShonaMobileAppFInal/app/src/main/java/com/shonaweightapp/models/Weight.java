package com.shonaweightapp.models;

import android.database.Cursor;

public class Weight {
   private String wid,lost,gained,goal,date;

    public Weight() {
    }

    public Weight(String wid, String lost, String gained, String goal, String date) {
        this.wid = wid;
        this.lost = lost;
        this.gained = gained;
        this.goal = goal;
        this.date = date;
    }

    public String getWid() {
        return wid;
    }

    public void setWid(String wid) {
        this.wid = wid;
    }

    public String getLost() {
        return lost;
    }

    public void setLost(String lost) {
        this.lost = lost;
    }

    public String getGained() {
        return gained;
    }

    public void setGained(String gained) {
        this.gained = gained;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void parse(Cursor cursor) {
        setLost(cursor.getString(0));
        setGained(cursor.getString(1));
        setGoal(cursor.getString(2));
        setDate(cursor.getString(3));
    }
}
