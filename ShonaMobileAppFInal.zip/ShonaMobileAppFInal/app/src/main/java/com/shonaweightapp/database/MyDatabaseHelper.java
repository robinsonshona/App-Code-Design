package com.shonaweightapp.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class MyDatabaseHelper extends SQLiteOpenHelper {

    private Context context;
    private static final String DATABASE_NAME = "newlife.db";
    private static final int DATABASE_VERSION =1;
    private static final String TABLE_NAME = "weights";

    private static final String COLUMN_ID = "id";
    private static final String COLUMN_GOAL = "goal";
    private static final String COLUMN_LOST = "lost";
    private static final String COLUMN_GAINED = "gained";
    private static final String COLUMN_DATE = "date";

    public MyDatabaseHelper(@Nullable Context context) {
        super(context,TABLE_NAME,null,DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE "+TABLE_NAME+
                " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT , "+
                COLUMN_GOAL + " TEXT , " + COLUMN_GAINED + " TEXT  , " + COLUMN_LOST + " TEXT ," + COLUMN_DATE + " TEXT );";
         db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(sqLiteDatabase);
    }


}
