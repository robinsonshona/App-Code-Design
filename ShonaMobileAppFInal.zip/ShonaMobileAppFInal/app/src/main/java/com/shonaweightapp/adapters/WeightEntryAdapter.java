package com.shonaweightapp.adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.mobile2app.R;
import com.mobile2app.activities.EditActivity;
import com.mobile2app.activities.MainActivity;
import com.mobile2app.database.NewLifeDB;
import com.mobile2app.models.Weight;
import com.mobile2app.storage.SharePreferenceManager;

import java.util.List;

public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.WeightViewHolder> {
    private Context mCtx;
    private List<Weight> weightList;
    NewLifeDB newLifeDB;
    public WeightEntryAdapter(Context mCtx, List<Weight>  weightList) {
        this.mCtx = mCtx;
        this. weightList =  weightList;
    }

    @NonNull
    @Override
    public WeightEntryAdapter.WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mCtx).inflate(R.layout.recyclerview_weight, parent, false);
        newLifeDB = new NewLifeDB(mCtx);
        return  new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, final int position) {
        final Weight weightEntry = weightList.get(position);
        holder.gained.append(String.valueOf(weightEntry.getGained())+" lbs");
        holder.lost.append(String.valueOf(weightEntry.getLost())+" lbs");
        holder.goal.append(String.valueOf(weightEntry.getGoal())+" lbs");
        holder.date.append(String.valueOf(weightEntry.getDate()));

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(mCtx);
                builder.setMessage("Are you sure you want to DELETE this item ?")
                        .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                               // newLifeDB.deleteEntry(String.valueOf(position));
                                removeListEntry(weightEntry);
                                weightList.remove(weightEntry);
                               // System.out.println("Entry ID : "+weightEntry.getId());
                                Intent intent = new Intent(mCtx,MainActivity.class);
                                mCtx.startActivity(intent);
                            }
                        })
                        .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                builder.show();
            }
        });

        holder.edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mCtx, EditActivity.class);
                intent.putExtra("id",String.valueOf(weightEntry.getWid()));
                intent.putExtra("gained",weightEntry.getGained());
                intent.putExtra("lost",weightEntry.getLost());
                intent.putExtra("goal", weightEntry.getGoal());
                intent.putExtra("date", weightEntry.getDate());
                mCtx.startActivity(intent);
            }
        });
    }


    @Override
    public int getItemCount() {
        return weightList.size();
    }

    class WeightViewHolder extends RecyclerView.ViewHolder{
        TextView gained,lost,goal,date;
        Button edit,delete;
        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            gained = itemView.findViewById(R.id.weight_gained);
            lost = itemView.findViewById(R.id.weight_lost);
            goal = itemView.findViewById(R.id.weight_goal);
            date = itemView.findViewById(R.id.weight_date);
            edit = itemView.findViewById(R.id.edit_weight);
            delete = itemView.findViewById(R.id.delete_weight);
        }
    }


    private void removeListEntry(Weight weight){
        final ProgressDialog progress = new ProgressDialog(mCtx);
        progress.setTitle("Loading");
        progress.setMessage("Wait while loading...");
        progress.setCancelable(false); // disable dismiss by tapping outside of the dialog
        progress.show();
        // To dismiss the dialog
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("weights/"+ SharePreferenceManager.getInstance(mCtx).getUser().getUsername()+"/"+weight.getWid());

        myRef.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                progress.dismiss();

            }
        });

    }
}
